package com.dev.hotelBilling;

public class Item {
	private int item_Code;
	private String food_Name;
	private double cost;
	public int getItemCode() {
		return item_Code;
	}
	public void setItemCode(int itemCode) {
		this.item_Code = itemCode;
	}
	public String getFoodName() {
		return food_Name;
	}
	public void setFoodName(String foodName) {
		this.food_Name = foodName;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Item [item_Code=" + item_Code + ", food_Name=" + food_Name + ", cost=" + cost + "]";
	}
}
