package com.dev.hotelBilling;

import java.util.Scanner;

public class InHotel {

	public static void main(String[] args) {
		ItemDetails id = new ItemDetails();

		Item i1 = new Item();
		i1.setItemCode(101);
		i1.setFoodName("Puri Sabzi");
		i1.setCost(40.00);

		Item i2 = new Item();
		i2.setItemCode(102);
		i2.setFoodName("Dosa");
		i2.setCost(65.00);

		Item i3 = new Item();
		i3.setItemCode(103);
		i3.setFoodName("Bread-Omlet");
		i3.setCost(70.00);

		Item i4 = new Item();
		i4.setItemCode(104);
		i4.setFoodName("Puri & Chicken-Keema");
		i4.setCost(100.00);

		Item i5 = new Item();
		i5.setItemCode(105);
		i5.setFoodName("Rasagola");
		i5.setCost(10.00);

		Item i6 = new Item();
		i6.setItemCode(106);
		i6.setFoodName("Rabidi");
		i6.setCost(50.00);
		
		boolean p = id.addFood("1", i1);
		boolean q = id.addFood("2", i2);
		boolean r = id.addFood("3", i3);
		boolean s = id.addFood("4", i4);
		boolean t = id.addFood("5", i5);	
		boolean u = id.addFood("6", i6);
		System.out.println(p+" "+q+" "+r+" "+s+" "+t+" "+u);
		id.showFood();
		
		boolean b = id.removeFood("4", i4);
		System.out.println(b);
		id.showFood();

		i1.setFoodName("Puri Sabji");
		id.updateFood("1", i1);
		id.showFood();
		
//---------------------------------------------------------------------
		
//		Scanner sc = new Scanner(System.in);
//		System.out.print("Enter the Value 1-4: ");
//		int val1 = sc.nextInt();
//		if (val1 == 1) {
//			boolean p = id.addFood("1", i1);
//			boolean q = id.addFood("2", i2);
//			boolean r = id.addFood("3", i3);
//			boolean s = id.addFood("4", i4);
//			boolean t = id.addFood("5", i5);	
//			boolean u = id.addFood("6", i6);
//			System.out.println(p+" "+q+" "+r+" "+s+" "+t+" "+u);
//			id.showFood();
//		}
//		else if (val1 == 2) {
//				int[] itemCode = {101,102,103,104,105,106}; 
//				System.out.println("Enter Item Code to order: ");
//				int ord = sc.nextInt();
//				int order = 0;
//
//				if (ord == itemCode[0] || ord == itemCode[1] || ord == itemCode[2] || ord == itemCode[3] || ord == itemCode[4] || ord == itemCode[5]) {
//					order++;
//					System.out.println("Total number of order= "+order);
//				}
//				else if (ord == 0) {
//					System.out.println("Total number of items= "+order);
//				}
//		}
//		else if (val1 == 3) {
//			System.out.print("Enter the Value A or B or C: ");
//			String val = sc.next();
//			
//			if (val == "A") {
//				System.out.print("Enter the food Name: ");
//				String name = sc.next();
//				System.out.println("Enter the food code: ");
//				int code = sc.nextInt();
//				System.out.println("Enter the food cost: ");
//				double cost = sc.nextDouble(); 
//				
//				Item k = new Item();
//				k.setItemCode(code);
//				k.setFoodName(name);
//				k.setCost(cost);
//				
//				System.out.println("Enter the key: ");
//				String key1 = sc.next();
//				System.out.println("Enter the value: ");
//				String value1 = sc.next(); 
//				boolean bool = id.addFood(key1, value1);
//			}
//			else if (val == "B") {
//				boolean b = id.removeFood("4", i4);
//				System.out.println(b);
//				id.showFood();
//
//			}
//			else if (val == "C") {
//				i1.setFoodName("Puri Sabji");
//				id.updateFood("1", i1);
//				id.showFood();
//			}
//		}
//		else if (val1 == 4) {
//			System.out.println();
//			int bill = 0;
//
//		}

	}

}
