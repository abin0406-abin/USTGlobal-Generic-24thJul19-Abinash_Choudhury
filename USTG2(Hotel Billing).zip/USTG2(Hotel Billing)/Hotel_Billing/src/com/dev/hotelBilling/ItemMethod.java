package com.dev.hotelBilling;

public interface ItemMethod {
	public void showFood();
	public boolean addFood(String key, Item i);
	public boolean removeFood(String key, Item i);
	public void updateFood(String key, Item i);
}
