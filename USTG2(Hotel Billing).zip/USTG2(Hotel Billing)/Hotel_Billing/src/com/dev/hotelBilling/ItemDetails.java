package com.dev.hotelBilling;

import java.util.HashMap;

public class ItemDetails implements ItemMethod {
	HashMap<String , Item> ihm = new HashMap<String, Item>();
	public static void main(String[] args) {

	}	

	@Override
	public boolean addFood(String key, Item i) {
		if (i != null) {
			ihm.put(key, i);
			return true;
		}
		return false;
	}

	@Override
	public void showFood() {
		System.out.println(ihm);
	}

	@Override
	public boolean removeFood(String key, Item i) {
		boolean ri = ihm.remove(key, i);
		if (ri) {
			return true;
		}
		return false;
	}

	@Override
	public void updateFood(String key, Item i) {
		ihm.replace(key, i);
	}

}
